<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AbrizamController extends Controller
{
   public function input()
    {
    	return view ('input');
    }
    public function process(Request $request)
    {
    	$messages = [
    	'required' => ':Attribute Must Be Filled Bro !!',
    	'min'	=> ':Attribute Must Be Filled Minimum :min Character Bro !!',
    	'max'	=> ':Attribute Must Be Filled Maximum :max Character Bro !!',
    	//'email' => ':Only Input Email Bro!!',
    	//'alpha_num' => ':Only Input Alphabet and Number Bro !!'
       	];
    	$this->validate($request,[
    		'name' => 'required|min:5|max:20',
    		'job' => 'required',
    		'age' => 'required|numeric'
    		//'email' => 'required|email',
    		//'num' => 'required|alpha_num'

    		],$messages);
    	return view ('process',['data' => $request]);
    }
}
