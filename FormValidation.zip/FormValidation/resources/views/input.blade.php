<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width", initial-scale=1.0>
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Tutorial Laravel Form Validation</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('/css/bootstrap.min.css') }}">
</head>

<body>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6">
				<div class="card mt-5">
					<div class="card-body">
						<h3 class="text-center">Abrizam Zafran</h3>
						<br/>
						{{-- show error validation --}}
						@if ( count ($errors) > 0) 
						<div class="alert alert-danger">
							<ul>
								@foreach ($errors->all() as $error)
								<li>{{ $error }}</li>
								@endforeach
							</ul>
						</div>
						@endif

						<br/>
						<!-- form validation -->
						<form action="/process" method="post">
							{{ csrf_field() }}

							<div class="form-group">
								<label for="name">Name</label>
								<input class="form-control" type="text" name="name" value="{{ old('name') }}">
							</div>
							<div class="form-group">
								<label for="Job">Job</label>
								<input class="form-control" type="text" name="job" value="{{ old('job') }}">
							</div>
							<div class="form-group">
								<label for="Age">Age</label>
								<input class="form-control" type="text" name="age" value="{{ old('age') }}">
							</div>
							<div class="form-group">
								<input class="btn btn-primary" type="submit" value="Process">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

</body>
</html>