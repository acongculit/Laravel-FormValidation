<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width", initial-scale=1.0>
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Tutorial Laravel Form Validation</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('/css/bootstrap.min.css') }}">
</head>

<body>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6">
				<div class="card mt-5">
					<div class="card-body">
						<h3 class="text-center">Abrizam Zafran</h3>
						<h3 class="my-4">Data Input :</h3>

						<table class="table table-bordered table-stripped" >
							<tr>
								<td style="width: 150px">Name</td>
								<td>{{ $data->name }}</td>
							</tr>
							<tr>
								<td>Job</td>
								<td>{{ $data->job }}</td>
							</tr>
							<tr>
								<td>Age</td>
								<td>{{ $data->age }}</td>
							</tr>
						</table>

						<a href="/input" class="btn btn-primary">Back</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>